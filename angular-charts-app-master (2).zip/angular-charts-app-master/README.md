# AngularChartsApp

Angular 8 Chart.js Tutorial with ng2-charts Examples - Display data using various charts such as pie chart, bar chart, radar, doughnut or bubble chart.

[Angular 8 Chart.js Tutorial with ng2-charts Examples](https://www.positronx.io/angular-chart-js-tutorial-with-ng2-charts-examples/)