export class Metrics {
    accuracy: string;
    ftrain: string;
    ftest: string;
    cpu: string;
    ram: string;
    time: string;
}

export class Algorithms {
    knn: string;
    rfc: string;
    lrc: string;
    dtc: string;
}