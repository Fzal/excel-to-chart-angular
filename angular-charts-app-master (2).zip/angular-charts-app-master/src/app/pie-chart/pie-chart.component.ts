import { Component } from '@angular/core';
import { ChartType, ChartOptions } from 'chart.js';
import { SingleDataSet, Label, monkeyPatchChartJsLegend, monkeyPatchChartJsTooltip } from 'ng2-charts';
import { appService } from '../app.service';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})

export class PieChartComponent {

  public pieChartOptions: ChartOptions = {
    responsive: true,
  };
  public pieChartLabels: Label[] = ['KNN', 'RFC', 'LRC', 'DTC'];
  public pieChartData: SingleDataSet = [0,0,0,0];
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public pieChartPlugins = [];
  timeTaken = [];
  data: any;

  constructor(private appService: appService) {
    monkeyPatchChartJsTooltip();
    monkeyPatchChartJsLegend();
  }

  ngOnInit() {
    this.reloadPage();
  }

  reloadPage() {
    this.data = this.appService.data;
    this.data.forEach(a => {
      this.timeTaken.push(a[5]*1000)
    })
    this.pieChartData = this.timeTaken;
  }
}
