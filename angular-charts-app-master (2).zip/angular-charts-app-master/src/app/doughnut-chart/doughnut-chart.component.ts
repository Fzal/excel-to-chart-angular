import { Component } from '@angular/core';
import { ChartType } from 'chart.js';
import { MultiDataSet, Label } from 'ng2-charts';
import { appService } from '../app.service';

@Component({
  selector: 'app-doughnut-chart',
  templateUrl: './doughnut-chart.component.html',
  styleUrls: ['./doughnut-chart.component.css']
})

export class DoughnutChartComponent {

  doughnutChartLabels: Label[] = ['KNN', 'RFC', 'LRC', 'DTC'];
  doughnutChartData: MultiDataSet = [
    [0,0,0,0]
  ];
  doughnutChartType: ChartType = 'doughnut';

  cpu = [];
  data: any;

  constructor(private appService: appService) {
  }

  
  ngOnInit() {
    this.reloadPage();
  }
  
  reloadPage() {
    this.data = this.appService.data;
    this.data.forEach(a => {
      this.cpu.push(a[3])
    })
    this.doughnutChartData = this.cpu;
  }

}
