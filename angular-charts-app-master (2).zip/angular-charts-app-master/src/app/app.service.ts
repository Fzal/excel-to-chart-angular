import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class appService {

    //  private approvalStageMessage = new BehaviorSubject('Basic Approval is required!');
    //  currentApprovalStageMessage = this.approvalStageMessage.asObservable();
    data: any [];

    constructor() {

    }
    //  updateApprovalMessage(message: string) {
    //  this.approvalStageMessage.next(message)
    //  }
}