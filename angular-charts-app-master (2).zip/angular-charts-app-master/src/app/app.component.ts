import { Component } from '@angular/core';
import * as XLSX from 'xlsx';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { appService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-charts-app';
  barChartLabels: Label[] = ['KNN', 'RFC', 'LRC', 'DTC'];
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];
  algos = [];

  public excelData: ExcelData[];
  data = [];
  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartData: ChartDataSets[] = [
    { data: [0, 0, 0, 0], label: 'Accuracy' }
  ];
  accuracy = [];
  time = [];
  ram = [];
  cpu = [];
  ftest = [];
  ftrain = [];
  labels = [];

  constructor(private appService: appService) {}

  onFileChange(evt: any) {
    //debugger
    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length == 1) {
      const reader: FileReader = new FileReader();
      reader.onload = (e: any) => {
        /* read workbook */
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
        // console.log(wb);
        /* grab first sheet */
        const sheetNames = wb.SheetNames;
        sheetNames.forEach(sheet=>{
          const ws: XLSX.WorkSheet = wb.Sheets[sheet];
          let metrics = <any>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
          this.labels = metrics[0]
          this.algos.push(metrics[1])
          // console.log(metrics[0]);
          // console.log(this.barChartData[0].data)
        })
        this.algos.forEach(a => {
          this.accuracy.push(a[0])
          this.ftrain.push(a[0])
          this.ftest.push(a[0])
          this.cpu.push(a[0])
          this.ram.push(a[0])
          this.time.push(a[0])
        })
        this.appService.data = this.algos;
        this.barChartData[0].data = this.accuracy;
        // const wsname: string = wb.SheetNames[0];
        // const ws: XLSX.WorkSheet = wb.Sheets[wsname];
        /* save data */
      };
      reader.readAsBinaryString(target.files[0]);
    }
  }

  uploadfile() {
    let keys = this.data.shift();
    let resArr = this.data.map((e) => {
      let obj = {};
      keys.forEach((key, i) => {
        obj[key] = e[i];
      });
      return obj;
    });
    //console.log(resArr);
    //resArr.forEach(function (value) {
    //  console.log(value);
    //})
    this.excelData = resArr;
  }
}
interface ExcelData {
  [index: number]: { Accuracy: string; };
}