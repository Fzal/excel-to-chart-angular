import { Component } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';

import * as XLSX from 'xlsx';
import { appService } from '../app.service';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})

export class BarChartComponent {
  title = 'app';
  public progress: number;
  public message: string;
  public excelData: ExcelData[];
  data = [];
  barChartOptions: ChartOptions = {
    responsive: true,
  };
  barChartLabels: Label[] = ['KNN', 'RFC', 'LRC', 'DTC'];
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];
  algos = [];

  barChartData: ChartDataSets[] = [
    { data: [0, 0, 0, 0], label: 'Accuracy' }
  ];
  accuracy = [];
  time = [];
  ram = [];
  cpu = [];
  ftest = [];
  ftrain = [];
  labels = [];

  constructor(private appService: appService) {}

  
  ngOnInit() {
    this.reloadPage();
  }
  
  reloadPage() {
    this.data = this.appService.data;
          this.data.forEach(a => {
          this.accuracy.push(a[0])
          this.ftrain.push(a[0])
          this.ftest.push(a[0])
          this.cpu.push(a[0])
          this.ram.push(a[0])
          this.time.push(a[0])
        })
        this.barChartData[0].data = this.accuracy;

  }

  // onFileChange(evt: any) {
  //   //debugger
  //   /* wire up file reader */
  //   const target: DataTransfer = <DataTransfer>(evt.target);
  //   if (target.files.length == 1) {
  //     const reader: FileReader = new FileReader();
  //     reader.onload = (e: any) => {
  //       /* read workbook */
  //       const bstr: string = e.target.result;
  //       const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });
  //       // console.log(wb);
  //       /* grab first sheet */
  //       const sheetNames = wb.SheetNames;
  //       sheetNames.forEach(sheet=>{
  //         const ws: XLSX.WorkSheet = wb.Sheets[sheet];
  //         let metrics = <any>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
  //         this.labels = metrics[0]
  //         this.algos.push(metrics[1])
  //         // console.log(metrics[0]);
  //         // console.log(this.barChartData[0].data)
  //       })
  //       this.algos.forEach(a => {
  //         this.accuracy.push(a[0])
  //         this.ftrain.push(a[0])
  //         this.ftest.push(a[0])
  //         this.cpu.push(a[0])
  //         this.ram.push(a[0])
  //         this.time.push(a[0])
  //       })
  //       this.barChartData[0].data = this.accuracy;
  //       // const wsname: string = wb.SheetNames[0];
  //       // const ws: XLSX.WorkSheet = wb.Sheets[wsname];
  //       /* save data */
  //     };
  //     reader.readAsBinaryString(target.files[0]);
  //   }
  // }

  // uploadfile() {
  //   let keys = this.data.shift();
  //   let resArr = this.data.map((e) => {
  //     let obj = {};
  //     keys.forEach((key, i) => {
  //       obj[key] = e[i];
  //     });
  //     return obj;
  //   });
  //   //console.log(resArr);
  //   //resArr.forEach(function (value) {
  //   //  console.log(value);
  //   //})
  //   this.excelData = resArr;
  // }

}
interface ExcelData {
  [index: number]: { Accuracy: string; };
}