import { Component, } from '@angular/core';
import { ChartDataSets, ChartOptions } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { appService } from '../app.service';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.css']
})

export class LineChartComponent {

  lineChartData: ChartDataSets[] = [
    { data: [0,0,0,0], label: 'F1 Score' },
  ];

  lineChartLabels: Label[] = ['KNN', 'RFC', 'LRC', 'DTC'];

  lineChartOptions = {
    responsive: true,
  };

  lineChartColors: Color[] = [
    {
      borderColor: 'black',
      backgroundColor: 'rgba(255,255,0,0.28)',
    },
  ];

  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType = 'line';
  cpu = [];
  data: any;

  constructor(private appService: appService) {
  }

  ngOnInit() {
    this.reloadPage();
  }

  reloadPage() {
    this.data = this.appService.data;
    this.data.forEach(a => {
      this.cpu.push(a[1])
    })
    this.lineChartData[0].data = this.cpu;
  }
}