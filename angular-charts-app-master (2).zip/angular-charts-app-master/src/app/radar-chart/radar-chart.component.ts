import { Component } from '@angular/core';
import { ChartDataSets, ChartType, RadialChartOptions } from 'chart.js';
import { Label } from 'ng2-charts';
import { appService } from '../app.service';

@Component({
  selector: 'app-radar-chart',
  templateUrl: './radar-chart.component.html',
  styleUrls: ['./radar-chart.component.css']
})

export class RadarChartComponent {

  public radarChartOptions: RadialChartOptions = {
    responsive: true,
  };
  public radarChartLabels: Label[] = ['KNN', 'RFC', 'LRC', 'DTC'];

  public radarChartData: ChartDataSets[] = [
    { data: [0,0,0,0], label: 'F1 Score' }
  ];
  public radarChartType: ChartType = 'radar';

  fscore = [];
  data: any;

  constructor(private appService: appService) {
  }

  ngOnInit() {
    this.reloadPage();
  }

  reloadPage() {
    this.data = this.appService.data;
    this.data.forEach(a => {
      this.fscore.push(a[1])
    })
    this.radarChartData[0].data = this.fscore;
  }
}
